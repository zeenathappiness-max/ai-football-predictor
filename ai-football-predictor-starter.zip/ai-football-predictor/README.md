# AI Football Predictor (starter)

A Streamlit starter app for exploring football match probability calculations.

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy with Streamlit Community Cloud

1. Push this repository to GitHub.
2. Open https://share.streamlit.io/ and sign in with GitHub.
3. Choose this repository and set the main file path to `app.py`.
4. Deploy.

## Data and limitations

- Demo fixtures are fictional and clearly labeled.
- API-Football mode loads current fixtures when you provide an API key.
- The first API integration uses neutral example team averages, so its predictions are only a UI/model demonstration, not evidence-based forecasts.
- For meaningful real-world predictions, add historical team results/statistics, build features from matches available before kickoff, and evaluate on a chronological holdout set.
- Never store API keys in a public repository. This starter accepts the key in the app sidebar; for a public deployment, use Streamlit secrets instead of exposing a shared key to visitors.
